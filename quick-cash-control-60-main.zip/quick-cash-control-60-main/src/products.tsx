
import React from 'react';
import Products from './pages/Products';

export default Products;
